import pygame
from pygame.locals import *

pygame.init()
screen = pygame.display.set_mode((800, 600))
clk = pygame.time.Clock()

# carichiamo il font e lo assegniamo alla variabile fnt
fnt = pygame.font.SysFont("Times New Roman", 80)

# inizializziamo una string vuota
s = ""
stringa = ''
# ciclo principale
done = False
while not done:
    # sottociclo degli eventi
    for ev in pygame.event.get():
        if ev.type == QUIT:
            done = True
        elif ev.type == KEYDOWN:                # e' stato premuto un tasto
            if ev.key == K_BACKSPACE:           # se e' il backspace ...
                stringa = stringa[0:-1]                     # slice notation
            elif ev.unicode.isprintable():      # altrimenti contolliamo se e' stampabile ...
                s += ev.unicode
                stringa += s
    # scriviamo s e otteniamo la Surface surf_text
    surf_text = fnt.render(stringa, True, "yellow")

    # disegniamo surf_text sullo schermo
    screen.fill((0, 0, 160))
    screen.blit(surf_text, (100, 100))
    pygame.display.flip()

    clk.tick(30)

pygame.quit()