import pygame, sys
import time
import random

pygame.init()
lunghezza=800
larghezza=1000

schermo=pygame.display.set_mode((lunghezza,larghezza))
pygame.display.set_caption("Azienda Lotta")

FPS_CLOCK = pygame.time.Clock()

bianco = (255,255,255)
nero = (0,0,0)
font = pygame.font.Font(".\\font\\pixel.ttf", 28)
font1 = pygame.font.Font(".\\font\\pixel.ttf", 52)
font2 = pygame.font.Font(".\\font\\pixel.ttf", 18)

pokemons = [
    {'nome' : 'Venusaur',
     'tipo': ['erba','veleno'],
     'ps': 270,
     'velox': 148,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\venusaur.wav'),
     'mosse':[{'nome': 'Frustata',
               'danni': 45,
               'tipo':'erba'},
              {'nome': 'Petalodanza',
               'danni': 80,
               'tipo':'erba'},
              {'nome': 'Velenoshock',
               'danni': 65,
               'tipo':'veleno'},
              {'nome': 'Velenobomba',
               'danni': 90,
               'tipo':'veleno'}],
     'davanti': pygame.image.load(".\\foto poke\\venusaur davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\venusaur back.png").convert_alpha()},
    {'nome' : 'Blastoise',
     'ps': 268,
     'velox': 144,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\blastoise.wav'),
     'mosse':[{'nome': 'Geloraggio',
               'danni': 85,
               'tipo':'ghiaccio'},
              {'nome': 'Idropompa',
               'danni': 85,
               'tipo':'acqua'},
              {'nome': 'Surf',
               'danni': 70,
               'tipo':'acqua'},
              {'nome': 'Ripresa',
               'danni': 0,
               'tipo':'normale'}],
     'davanti': pygame.image.load(".\\foto poke\\blastoise davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\blastoise back.png").convert_alpha()},
    {'nome' : 'Charizard',
     'tipo': ['fuoco','volante'],
     'ps': 266,
     'velox': 184,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\charizard.wav'),
     'mosse':[{'nome': 'Lanciafiamme',
               'danni': 90,
               'tipo':'fuoco'},
              {'nome': 'Fuocobomba',
               'danni': 95,
               'tipo':'fuoco'},
              {'nome': "Att. d'ala",
               'danni': 60,
               'tipo':'volante'},
              {'nome': 'Aeroassalto',
               'danni': 60,
               'tipo':'volante'}],
     'davanti': pygame.image.load(".\\foto poke\\charizard davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\charizard back.png").convert_alpha()},
    {'nome' : 'Meganium',
     'tipo': ['erba'],
     'ps': 270,
     'velox': 152,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\meganium.wav'),
     'mosse':[{'nome': 'Frustata',
               'danni': 45,
               'tipo':'erba'},
              {'nome': 'Fiortempesta',
               'danni': 90,
               'tipo':'erba'},
              {'nome': 'Sintesi',
               'danni': 0,
               'tipo':'erba'},
              {'nome': 'Terremoto',
               'danni': 100,
               'tipo':'terra'}],
     'davanti': pygame.image.load(".\\foto poke\\meganium davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\meganium back.png").convert_alpha()},
    {'nome' : 'Typhlosion',
     'tipo': ['fuoco'],
     'ps': 266,
     'velox': 184,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\typhlosion.wav'),
     'mosse':[{'nome': 'Lanciafiamme',
               'danni': 90,
               'tipo':'fuoco'},
              {'nome': 'Fuocobomba',
               'danni': 95,
               'tipo':'fuoco'},
              {'nome': "Ruotafuoco",
               'danni': 45,
               'tipo':'fuoco'},
              {'nome': 'Palla Ombra',
               'danni': 85,
               'tipo':'spettro'}],
     'davanti': pygame.image.load(".\\foto poke\\typhlosion davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\typhlosion back.png").convert_alpha()},
    {'nome' : 'Feraligatr',
     'tipo': ['acqua'],
     'ps': 280,
     'velox': 144,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\feraligatr.wav'),
     'mosse':[{'nome': 'Sgranocchio',
               'danni': 80,
               'tipo':'buio'},
              {'nome': 'Idropompa',
               'danni': 85,
               'tipo':'acqua'},
              {'nome': 'Surf',
               'danni':70,
               'tipo':'acqua'},
              {'nome': 'Pistolacqua',
               'danni': 50,
               'tipo':'acqua'}],
     'davanti': pygame.image.load(".\\foto poke\\feraligatr davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\feraligatr back.png").convert_alpha()},
    {'nome' : 'Sceptile',
     'tipo': ['erba'],
     'ps': 250,
     'velox': 220,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\sceptile.wav'),
     'mosse':[{'nome': 'Frustata',
               'danni': 45,
               'tipo':'erba'},
              {'nome': 'Giga Ass.',
               'danni': 80,
               'tipo':'erba'},
              {'nome': 'Fendifoglia',
               'danni': 90,
               'tipo':'erba'},
              {'nome': 'Taglio',
               'danni': 50,
               'tipo':'normale'}],
     'davanti': pygame.image.load(".\\foto poke\\sceptile davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\sceptile back.png").convert_alpha()},
    {'nome' : 'Blaziken',
     'tipo': ['fuoco','lotta'],
     'ps': 270,
     'velox': 148,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\blaziken.wav'),
     'mosse':[{'nome': 'Lanciafiamme',
               'danni': 90,
               'tipo':'fuoco'},
              {'nome': 'Fuocobomba',
               'danni': 95,
               'tipo':'fuoco'},
              {'nome': "Calcinvolo",
               'danni': 80,
               'tipo':'lotta'},
              {'nome': 'Zuffa',
               'danni': 100,
               'tipo':'lotta'}],
     'davanti': pygame.image.load(".\\foto poke\\blaziken davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\blaziken back.png").convert_alpha()},
    {'nome' : 'Swampert',
     'tipo': ['acqua','terra'],
     'ps': 310,
     'velox': 112,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\swampert.wav'),
     'mosse':[{'nome': 'Fango Sberla',
               'danni': 50,
               'tipo':'terra'},
              {'nome': 'Idropompa',
               'danni': 85,
               'tipo':'acqua'},
              {'nome': 'Surf',
               'danni': 70,
               'tipo':'acqua'},
              {'nome': 'Terremoto',
               'danni': 100,
               'tipo':'terra'}],
     'davanti': pygame.image.load(".\\foto poke\\swampert davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\swampert back.png").convert_alpha()},
    {'nome' : 'Torterra',
     'tipo': ['erba','terra'],
     'ps': 300,
     'velox': 105,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\torterra.wav'),
     'mosse':[{'nome': 'Terremoto',
               'danni': 100,
               'tipo':'terra'},
              {'nome': 'Giga Ass.',
               'danni': 80,
               'tipo':'erba'},
              {'nome': 'Sgranocchio',
               'danni': 80,
               'tipo':'buio'},
              {'nome': 'Foglielama',
               'danni': 50,
               'tipo':'erba'}],
     'davanti': pygame.image.load(".\\foto poke\\torterra davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\torterra back.png").convert_alpha()},
    {'nome' : 'Infernape',
     'tipo': ['fuoco','lotta'],
     'ps': 262,
     'velox': 198,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\infernape.wav'),
     'mosse':[{'nome': 'Ruotafuoco',
               'danni': 60,
               'tipo':'fuoco'},
              {'nome': 'Fuocobomba',
               'danni': 95,
               'tipo':'fuoco'},
              {'nome': "Breccia",
               'danni': 80,
               'tipo':'lotta'},
              {'nome': 'Zuffa',
               'danni': 100,
               'tipo':'lotta'}],
     'davanti': pygame.image.load(".\\foto poke\\infernape davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\infernape back.png").convert_alpha()},
    {'nome' : 'Empoleon',
     'tipo': ['acqua','acciaio'],
     'ps': 278,
     'velox': 112,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\empoleon.wav'),
     'mosse':[{'nome': 'Alacciaio',
               'danni': 50,
               'tipo':'acciaio'},
              {'nome': 'Idropompa',
               'danni': 85,
               'tipo':'acqua'},
              {'nome': 'Surf',
               'danni': 70,
               'tipo':'acqua'},
              {'nome': 'Metaltestata',
               'danni': 90,
               'tipo':'acciaio'}],
     'davanti': pygame.image.load(".\\foto poke\\empoleon davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\empoleon back.png").convert_alpha()},
    {'nome' : 'Serperior',
     'tipo': ['erba'],
     'ps': 260,
     'velox': 207,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\serperior.wav'),
     'mosse':[{'nome': 'Frustata',
               'danni': 45,
               'tipo':'erba'},
              {'nome': 'Fendifoglia',
               'danni': 90,
               'tipo':'erba'},
              {'nome': 'Sintesi',
               'danni': 0,
               'tipo':'erba'},
              {'nome': 'Foglielama',
               'danni': 50,
               'tipo':'erba'}],
     'davanti': pygame.image.load(".\\foto poke\\serperior davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\serperior back.png").convert_alpha()},
    {'nome' : 'Emboar',
     'tipo': ['fuoco','lotta'],
     'ps': 330,
     'velox': 121,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\emboar.wav'),
     'mosse':[{'nome': 'Fuococarica',
               'danni': 80,
               'tipo':'fuoco'},
              {'nome': 'Fuocobomba',
               'danni': 95,
               'tipo':'fuoco'},
              {'nome': "Sberletese",
               'danni': 50,
               'tipo':'lotta'},
              {'nome': 'Zuffa',
               'danni': 100,
               'tipo':'lotta'}],
     'davanti': pygame.image.load(".\\foto poke\\emboar davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\emboar back.png").convert_alpha()},
    {'nome' : 'Samurott',
     'tipo': ['acqua'],
     'ps': 300,
     'velox': 130,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\samurott.wav'),
     'mosse':[{'nome': 'Acqua getto',
               'danni': 60,
               'tipo':'acqua'},
              {'nome': 'Conchilama',
               'danni': 90,
               'tipo':'acqua'},
              {'nome': 'Surf',
               'danni': 70,
               'tipo':'acqua'},
              {'nome': 'Geloraggio',
               'danni': 85,
               'tipo':'ghiaccio'}],
     'davanti': pygame.image.load(".\\foto poke\\samurott davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\samurott back.png").convert_alpha()},
    {'nome' : 'Chesnaught',
     'tipo': ['erba','lotta'],
     'ps': 286,
     'velox': 119,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\chesnaught.wav'),
     'mosse':[{'nome': 'Mazzuolegno',
               'danni': 90,
               'tipo':'erba'},
              {'nome': 'Semebomba',
               'danni': 60,
               'tipo':'erba'},
              {'nome': 'Martelpugno',
               'danni': 100,
               'tipo':'lotta'},
              {'nome': 'Breccia',
               'danni': 70,
               'tipo':'lotta'}],
     'davanti': pygame.image.load(".\\foto poke\\chesnaught davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\chesnaught back.png").convert_alpha()},
    {'nome' : 'Delphox',
     'tipo': ['fuoco','psico'],
     'ps': 260,
     'velox': 191,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\delphox.wav'),
     'mosse':[{'nome': 'Psichico',
               'danni': 90,
               'tipo':'psico'},
              {'nome': 'Palla Ombra',
               'danni': 85,
               'tipo':'spettro'},
              {'nome': 'Lanciafiamme',
               'danni': 90,
               'tipo':'fuoco'},
              {'nome': 'Fuocobomba',
               'danni': 95,
               'tipo':'fuoco'}],
     'davanti': pygame.image.load(".\\foto poke\\delphox davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\delphox back.png").convert_alpha()},
    {'nome' : 'Greninja',
     'tipo': ['acqua','buio'],
     'ps': 254,
     'velox': 224,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\greninja.wav'),
     'mosse':[{'nome': 'Nero-pulsar',
               'danni': 80,
               'tipo':'buio'},
              {'nome': 'Idropompa',
               'danni': 85,
               'tipo':'acqua'},
              {'nome': 'Surf',
               'danni': 70,
               'tipo':'acqua'},
              {'nome': 'Geloraggio',
               'danni': 85,
               'tipo':'ghiaccio'}],
     'davanti': pygame.image.load(".\\foto poke\\greninja davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\greninja back.png").convert_alpha()},
    {'nome' : 'Dragonite',
     'tipo': ['drago','volante'],
     'ps': 291,
     'velox': 148,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\dragonite.wav'),
     'mosse':[{'nome': 'Dragobolide',
               'danni': 100,
               'tipo':'drago'},
              {'nome': 'Fuocopugno',
               'danni': 65,
               'tipo':'fuoco'},
              {'nome': 'Tuonopugno',
               'danni': 65,
               'tipo':'elettro'},
              {'nome': 'Aeroassalto',
               'danni': 60,
               'tipo':'volante'}],
     'davanti': pygame.image.load(".\\foto poke\\dragonite davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\dragonite back.png").convert_alpha()},
    {'nome' : 'Salamence',
     'tipo': ['drago','volante'],
     'ps': 300,
     'velox': 184,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\salamence.wav'),
     'mosse':[{'nome': 'Dragobolide',
               'danni': 100,
               'tipo':'drago'},
              {'nome': 'Pietrataglio',
               'danni': 90,
               'tipo':'roccia'},
              {'nome': 'Dragoartigli',
               'danni': 70,
               'tipo':'drago'},
              {'nome': 'Fuocobomba',
               'danni': 95,
               'tipo':'fuoco'}],
     'davanti': pygame.image.load(".\\foto poke\\salamence davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\salamence back.png").convert_alpha()},
    {'nome' : 'Mewtwo',
     'tipo': ['psico'],
     'ps': 322,
     'velox': 238,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\mewtwo.wav'),
     'mosse':[{'nome': 'Psichico',
               'danni': 90,
               'tipo':'psico'},
              {'nome': 'Palla Ombra',
               'danni': 85,
               'tipo':'spettro'},
              {'nome': 'Psicotaglio',
               'danni': 100,
               'tipo':'psico'},
              {'nome': 'Ripresa',
               'danni': 0,
               'tipo':'normale'}],
     'davanti': pygame.image.load(".\\foto poke\\mewtwo davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\mewtwo back.png").convert_alpha()},
    {'nome' : 'Snorlax',
     'tipo': ['normale'],
     'ps': 430,
     'velox': 58,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\snorlax.wav'),
     'mosse':[{'nome': 'Pesobomba',
               'danni': 80,
               'tipo':'acciaio'},
              {'nome': 'Corposcontro',
               'danni': 80,
               'tipo':'normale'},
              {'nome': 'Cozzata Zen',
               'danni': 70,
               'tipo':'psico'},
              {'nome': 'Ripresa',
               'danni': 0,
               'tipo':'normale'}],
     'davanti': pygame.image.load(".\\foto poke\\snorlax davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\snorlax back.png").convert_alpha()},
    {'nome' : 'Tyranitar',
     'tipo': ['roccia','buio'],
     'ps': 310,
     'velox': 114,
     'verso' : pygame.mixer.Sound('.\\suoni poke\\tyranitar.wav'),
     'mosse':[{'nome': 'Pietrataglio',
               'danni': 90,
               'tipo':'roccia'},
              {'nome': 'Nero-pulsar',
               'danni': 80,
               'tipo':'buio'},
              {'nome': 'Sgranocchio',
               'danni': 80,
               'tipo':'buio'},
              {'nome': 'Terremoto',
               'danni': 100,
               'tipo':'terra'}],
     'davanti': pygame.image.load(".\\foto poke\\tyranitar davanti.png").convert_alpha(),
     'dietro': pygame.image.load(".\\foto poke\\tyranitar back.png").convert_alpha()}]
tipi = {
    'erba' : pygame.image.load(".\\schermate lotta\\erba.png"),
        
    'veleno' : pygame.image.load(".\\schermate lotta\\veleno.png"),
        
    'acqua' : pygame.image.load(".\\schermate lotta\\acqua.png"),
        
    'normale' : pygame.image.load(".\\schermate lotta\\normale.png"),
        
    'fuoco' : pygame.image.load(".\\schermate lotta\\fuoco.png"),
        
    'volante' : pygame.image.load(".\\schermate lotta\\volante.png"),
        
    'spettro' : pygame.image.load(".\\schermate lotta\\spettro.png"),
        
    'buio' : pygame.image.load(".\\schermate lotta\\buio.png"),
        
    'lotta' : pygame.image.load(".\\schermate lotta\\lotta.png"),
        
    'terra' : pygame.image.load(".\\schermate lotta\\terra.png"),
        
    'acciaio' : pygame.image.load(".\\schermate lotta\\acciaio.png"),
        
    'psico' : pygame.image.load(".\\schermate lotta\\psico.png"),
        
    'ghiaccio' : pygame.image.load(".\\schermate lotta\\ghiaccio.png"),
        
    'drago' : pygame.image.load(".\\schermate lotta\\drago.png"),
        
    'elettro' : pygame.image.load(".\\schermate lotta\\elettro.png"),
        
    'roccia' : pygame.image.load(".\\schermate lotta\\roccia.png")}

pokemon1 = pokemons.pop(random.randint(0,22))
pok1=pokemon1['davanti']

pokemon2 = pokemons.pop(random.randint(0,21))
pok2=pokemon2['davanti']
    
pokemon3 = pokemons.pop(random.randint(0,20))
pok3=pokemon3['davanti']
    
pokemonavv = pokemons[random.randint(0,19)]
    
def sfondoiniziale():
    sfondo1=pygame.image.load(".\\foto sfondo\\sfondo iniziale\\sfondo iniziale 20.png")
    schermo.blit(sfondo1,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo1=pygame.image.load(".\\foto sfondo\\sfondo iniziale\\sfondo iniziale 40.png")
    schermo.blit(sfondo1,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo1=pygame.image.load(".\\foto sfondo\\sfondo iniziale\\sfondo iniziale 60.png")
    schermo.blit(sfondo1,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo1=pygame.image.load(".\\foto sfondo\\sfondo iniziale\\sfondo iniziale 80.png")
    schermo.blit(sfondo1,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo1=pygame.image.load(".\\foto sfondo\\sfondo iniziale\\sfondo iniziale.png")
    schermo.blit(sfondo1,(0,0))
    pygame.display.update()
    time.sleep(0.20)

def sfondoscelta():
    sfondo2=pygame.image.load(".\\foto sfondo\\sfondo 2\\Sfondo2 20.png")
    schermo.blit(sfondo2,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo2=pygame.image.load(".\\foto sfondo\\sfondo 2\\Sfondo2 40.png")
    schermo.blit(sfondo2,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo2=pygame.image.load(".\\foto sfondo\\sfondo 2\\Sfondo2 60.png")
    schermo.blit(sfondo2,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo2=pygame.image.load(".\\foto sfondo\\sfondo 2\\Sfondo2 80.png")
    schermo.blit(sfondo2,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondo2=pygame.image.load(".\\foto sfondo\\sfondo 2\\Sfondo2 100.png")
    schermo.blit(sfondo2,(0,0))
    pygame.display.update()
    time.sleep(0.20)

def animazionipokemon():
    for _ in range(60):
        cas1=pokemons[random.randint(0,19)]['davanti']
        schermo.blit(cas1,(295,45))

        cas2=pokemons[random.randint(0,19)]['davanti']
        schermo.blit(cas2,(35,147))
        
        cas3=pokemons[random.randint(0,19)]['davanti']
        schermo.blit(cas3,(565,147))
        pygame.display.update()
        
        time.sleep(0.05)
        sfondo2=pygame.image.load(".\\foto sfondo\\sfondo 2\\sfondo2 100.png").convert_alpha()
        schermo.blit(sfondo2,(0,0))
        pygame.display.update()

def scelta():
    global pokemonmio
    pulsante_premuto = False
    
    while not pulsante_premuto:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = pygame.mouse.get_pos()
                    areap1 = pygame.Rect(295, 45, pok1.get_width(), pok1.get_height()).collidepoint(click)
                    areap2 = pygame.Rect(35, 147, pok2.get_width(), pok2.get_height()).collidepoint(click)
                    areap3 = pygame.Rect(565, 147, pok3.get_width(), pok3.get_height()).collidepoint(click)
                    
                    if areap1:
                        pokemonmio = pokemon1
                        pulsante_premuto = True
                    elif areap2:
                        pokemonmio = pokemon2
                        pulsante_premuto = True
                    elif areap3:
                        pokemonmio = pokemon3
                        pulsante_premuto = True
         
def vedipoke():
    sfondocrema=pygame.image.load(".\\foto sfondo\\sfondo 3\\crema 20.png")
    schermo.blit(sfondocrema,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondocrema=pygame.image.load(".\\foto sfondo\\sfondo 3\\crema 40.png")
    schermo.blit(sfondocrema,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondocrema=pygame.image.load(".\\foto sfondo\\sfondo 3\\crema 60.png")
    schermo.blit(sfondocrema,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondocrema=pygame.image.load(".\\foto sfondo\\sfondo 3\\crema 80.png")
    schermo.blit(sfondocrema,(0,0))
    pygame.display.update()
    time.sleep(0.20)
    sfondocrema=pygame.image.load(".\\foto sfondo\\sfondo 3\\crema.png")
    schermo.blit(sfondocrema,(0,0))
    pygame.display.update()  
    testoscelto = font.render("Hai scelto", True, (0,0,0))
    schermo.blit(testoscelto, (100, 200))
    testoscelto = font.render(pokemonmio['nome'], True, (0,0,0))
    schermo.blit(testoscelto, (100, 300))
    pygame.display.update()
    suono = pokemonmio['verso']
    suono.play()
    time.sleep(0.5)
    schermo.blit(pokemonmio['davanti'], (300, 400))
    pygame.display.update()
    time.sleep(0.5)
    tp = 'Tipo: '
    for i in pokemonmio['tipo']:
        tp += i + ','
    testoscelto = font.render(tp[:-1], True, (0,0,0))
    schermo.blit(testoscelto, (100, 700))
    pygame.display.update()
    time.sleep(2.0)

def sfondolotta():
    musichetta = pygame.mixer.Sound('.\\altri suoni\\inizio.wav')
    musichetta.play()
    sfondol=pygame.image.load(".\\schermate lotta\\inizio\\pt1.png").convert_alpha()
    schermo.blit(sfondol,(0,0))
    pygame.display.update()
    time.sleep(0.30)
    sfondol=pygame.image.load(".\\schermate lotta\\inizio\\pt2.png").convert_alpha()
    schermo.blit(sfondol,(0,0))
    pygame.display.update()
    time.sleep(0.30)
    sfondol=pygame.image.load(".\\schermate lotta\\inizio\\pt3.png").convert_alpha()
    schermo.blit(sfondol,(0,0))
    pygame.display.update()
    time.sleep(0.30)
    sfondol=pygame.image.load(".\\schermate lotta\\inizio\\pt4.png").convert_alpha()
    schermo.blit(sfondol,(0,0))
    pygame.display.update()
    time.sleep(0.30)
    sfondol=pygame.image.load(".\\schermate lotta\\inizio\\pt5.png").convert_alpha()
    schermo.blit(sfondol,(0,0))
    pygame.display.update()
    time.sleep(0.30)
    sfondol=pygame.image.load(".\\schermate lotta\\inizio\\pt6.png").convert_alpha()
    schermo.blit(sfondol,(0,0))
    pygame.display.update()
    time.sleep(0.30)
    sfondol=pygame.image.load(".\\schermate lotta\\inizio\\pt7.png").convert_alpha()
    schermo.blit(sfondol,(0,0))
    pygame.display.update()
    time.sleep(0.30)
    
    sfondol=pygame.image.load(".\\foto sfondo\\sfondo lotta\\sfondo lotta.png")
    schermo.blit(sfondol,(0,0))
    fotopokeavv = pokemonavv['davanti']
    schermo.blit(fotopokeavv,(500,60))
    suono = pokemonavv['verso']
    suono.play()
    pygame.display.update()
    time.sleep(2.0)
    fotopokemio = pokemonmio['dietro']
    suono = pokemonmio['verso']
    suono.play()
    schermo.blit(fotopokemio,(100,250))
    pygame.display.update()
    time.sleep(1.0)
    dialogo=pygame.image.load(".\\foto sfondo\\sfondo lotta\\dialogo.png")
    schermo.blit(dialogo,(0,478))
    testoscelto = font.render(f"É apparso {pokemonavv['nome']}!", True, (0,0,0))
    schermo.blit(testoscelto, (30, 500))
    testoscelto = font.render(f"Combatti {pokemonmio['nome']}!", True, (0,0,0))
    schermo.blit(testoscelto, (30, 535))
    pygame.display.update()
    time.sleep(2.0)
    
def pulsantelotta():
    pulsante_premuto = False
    dialogo=pygame.image.load(".\\foto sfondo\\sfondo lotta\\dialogo.png")
    schermo.blit(dialogo,(0,478))
    pygame.display.update()
    plotta = font1.render(f" LOTTA!", True, (255,255,255),(128, 0, 0))
    schermo.blit(plotta, (220, 485))
    pygame.display.update()
    while not pulsante_premuto:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = pygame.mouse.get_pos()
                    areaplotta = pygame.Rect(220, 485, plotta.get_width(), plotta.get_height()).collidepoint(click)

                    if areaplotta:
                        pulsante_premuto = True

    
   
def mostramosse():
    global tipomossa1, tipomossa2, tipomossa3, tipomossa4
    sflotta2 = pygame.image.load(".\\schermate lotta\\scelta.png")
    schermo.blit(sflotta2,(0,478))
    pygame.display.update()
        
    tipomossa1 = tipi[pokemonmio['mosse'][0]['tipo']]
    schermo.blit(tipomossa1,(0,548))
    tipomossa2 = tipi[pokemonmio['mosse'][1]['tipo']]
    schermo.blit(tipomossa2,(408,548))
    tipomossa3 = tipi[pokemonmio['mosse'][2]['tipo']]
    schermo.blit(tipomossa3,(0,752))
    tipomossa4 = tipi[pokemonmio['mosse'][3]['tipo']]
    schermo.blit(tipomossa4,(408,752))
    
    nomemossa1 = font.render(pokemonmio['mosse'][0]['nome'], True, (0,0,0))
    schermo.blit(nomemossa1,(30,595))
    nomemossa2 = font.render(pokemonmio['mosse'][1]['nome'], True, (0,0,0))
    schermo.blit(nomemossa2,(442,595))
    nomemossa3 = font.render(pokemonmio['mosse'][2]['nome'], True, (0,0,0))
    schermo.blit(nomemossa3,(30,800))
    nomemossa4 = font.render(pokemonmio['mosse'][3]['nome'], True, (0,0,0))
    schermo.blit(nomemossa4,(442,800))
    
    hpavv = pygame.image.load(".\\schermate lotta\\hp avv.png").convert_alpha()
    schermo.blit(hpavv, (0,70))
    hpmio = pygame.image.load(".\\schermate lotta\\hp mio.png").convert_alpha()
    schermo.blit(hpmio, (500,340))
    hpio = font2.render(str(pokemonmio['ps']), True, bianco)
    schermo.blit(hpio,(625,355))
    hpav = font2.render(str(pokemonavv['ps']), True, bianco)
    schermo.blit(hpav,(95,85))
    pygame.display.update()
    
def attaccomio():
    selezione_mossa = False

    while not selezione_mossa:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = pygame.mouse.get_pos()
                    areamossa1 = pygame.Rect(0, 548, tipomossa1.get_width(), tipomossa1.get_height()).collidepoint(click)
                    areamossa2 = pygame.Rect(408, 548, tipomossa2.get_width(), tipomossa2.get_height()).collidepoint(click)
                    areamossa3 = pygame.Rect(0, 752, tipomossa3.get_width(), tipomossa3.get_height()).collidepoint(click)
                    areamossa4 = pygame.Rect(408, 752, tipomossa4.get_width(), tipomossa4.get_height()).collidepoint(click)
                    
                    if areamossa1:
                        mossamia = pokemonmio['mosse'][0]
                        mossa(mossamia, pokemonavv, pokemonmio)
                        selezione_mossa = True
                    elif areamossa2:
                        mossamia = pokemonmio['mosse'][1]
                        mossa(mossamia, pokemonavv, pokemonmio)
                        selezione_mossa = True
                    elif areamossa3:
                        mossamia = pokemonmio['mosse'][2]
                        mossa(mossamia, pokemonavv, pokemonmio)
                        selezione_mossa = True
                    elif areamossa4:
                        mossamia = pokemonmio['mosse'][3]
                        mossa(mossamia, pokemonavv, pokemonmio)
                        selezione_mossa = True
                        
        if not selezione_mossa:
            hpavv = pygame.image.load(".\\schermate lotta\\hp avv.png").convert_alpha()
            schermo.blit(hpavv, (0, 70))
            hpmio = pygame.image.load(".\\schermate lotta\\hp mio.png").convert_alpha()
            schermo.blit(hpmio, (500, 340))
            hpio = font2.render(str(pokemonmio['ps']), True, bianco)
            schermo.blit(hpio, (625, 355))
            hpav = font2.render(str(pokemonavv['ps']), True, bianco)
            schermo.blit(hpav, (95, 85))
            pygame.display.update()
        
def mossa(att, contro, pro):
    global eff
    if att['tipo'] == "fuoco":
        if 'erba' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'acqua' in contro['tipo'] or 'drago' in contro['tipo'] or 'roccia' in contro['tipo'] or 'fuoco' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
            
    elif att['tipo'] == "erba":
          
        if contro['tipo'] == ['acqua', 'terra']:
            danni = int(att['danni'] * 4)
            eff = 2
        elif contro['tipo'] == ['erba', 'veleno'] or contro['tipo'] == ['fuoco', 'volante'] or contro['tipo'] == ['drago', 'volante']:
            danni = int(att['danni'] / 4)
            eff = 1
        elif contro['tipo'] == ['acqua', 'acciaio'] or contro['tipo'] == ['erba', 'terra']:
            danni = att['danni']
            eff = 0
        elif 'acqua' in contro['tipo'] or 'roccia' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'erba' in contro['tipo'] or 'fuoco' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "acqua":
        if contro['tipo'] == ['acqua', 'terra'] or contro['tipo'] == ['erba', 'terra']:
            danni = att['danni']
            eff = 0
        elif 'fuoco' in contro['tipo'] or 'roccia' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'erba' in contro['tipo'] or 'drago' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
            
    elif att['tipo'] == "elettro":
        if contro['tipo'] == ['drago', 'volante']:
            danni = att['danni']
            eff = 0
        elif contro['tipo'] == ['acqua', 'terra'] or contro['tipo'] == ['erba', 'terra']:
            danni = 0
            eff = 3
        elif 'volante' in contro['tipo'] or 'acqua' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'erba' in contro['tipo'] or 'drago' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
            
    elif att['tipo'] == "drago":
        if 'drago' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'acciaio' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "acciaio":
        if contro['tipo'] == ['acqua', 'acciaio']:
            danni = int(att['danni'] / 4)
            eff = 1
        elif 'roccia' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'acciaio' in contro['tipo'] or 'fuoco' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
            
    elif att['tipo'] == "buio":
        if 'psico' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'lotta' in contro['tipo'] or 'buio' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "ghiaccio":
        if contro['tipo'] == ['acqua', 'acciaio']:
            danni = int(att['danni'] / 4)
            eff = 1
        elif contro['tipo'] == ['drago', 'volante'] or contro['tipo'] == ['erba', 'terra']:
            danni = int(att['danni'] * 4)
            eff = 2
        elif contro['tipo'] == ['fuoco', 'volante'] or contro['tipo'] == ['acqua', 'terra']:
            danni = att['danni']
            eff = 0
        elif 'erba' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'fuoco' in contro['tipo'] or 'ghiaccio' in contro['tipo'] or 'acciaio' in contro['tipo'] or 'acqua' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "lotta":
        if contro['tipo'] == ['roccia', 'buio']:
            danni = int(att['danni'] * 4)
            eff = 2
        elif 'normale' in contro['tipo'] or 'normale' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'veleno' in contro['tipo'] or 'volante' in contro['tipo'] or 'psico' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "normale":
    
        if 'roccia' in contro['tipo'] or 'acciaio' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "psico":
        if 'lotta' in contro['tipo'] or 'veleno' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'acciaio' in contro['tipo'] or 'psico' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        elif 'buio' in contro['tipo']:
            danni = 0
            eff = 3
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "roccia":
        if contro['tipo'] == ['fuoco', 'volante']:
            danni = int(att['danni'] * 4)
            eff = 2
        if contro['tipo'] == ['fuoco', 'lotta']:
            danni = att['danni']
            eff = 0
        elif 'fuoco' in contro['tipo'] or 'volante' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'terra' in contro['tipo'] or 'acciaio' in contro['tipo'] or 'lotta' in contro['tipo'] or 'acqua' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "spettro":
        if 'normale' in contro['tipo']:
            danni = 0
            eff = 3
        elif 'psico' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'buio' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "terra":
        if 'volante' in contro['tipo']:
            danni = 0
            eff = 3
        elif contro['tipo'] == ['erba', 'veleno']:
            danni = att['danni']
            eff = 0
        elif 'roccia' in contro['tipo'] or 'acciaio' in contro['tipo'] or 'fuoco' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'erba' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    elif att['tipo'] == "veleno":
        if contro['tipo'] == ['erba', 'veleno'] or contro['tipo'] == ['erba', 'terra']:
            danni = att['danni']
            eff = 0
        elif 'acciaio' in contro['tipo']:
            danni = 0   
            eff = 3
        elif 'erba' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'terra' in contro['tipo'] or 'roccia' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
            
    elif att['tipo'] == "volante":
        if 'erba' in contro['tipo'] or 'lotta' in contro['tipo']:
            danni = int(att['danni'] * 2)
            eff = 2
        elif 'acciaio' in contro['tipo'] or 'roccia' in contro['tipo']:
            danni = int(att['danni'] / 2)
            eff = 1
        else: 
            danni = att['danni']
            eff = 0
    
    if att['tipo'] in pro['tipo']:
        danni *= 1.2
    if random.randint(0,10) == 5:
        danni *= 1.5
    
    contro['ps'] -= int(danni)
    
    if att['nome'] == 'Ripresa' or att['nome'] == 'Sintesi':
        pro['ps'] += 60
    if att['nome'] == 'Giga Ass.':
        pro['ps'] += int(danni/2)
    print(att['tipo'],danni)
    animazionemossa(att,pro,contro)
    time.sleep(1.0)
    if pokemonmio['ps'] < 1:
        pokemonmio['ps'] = 0
    if pokemonavv['ps'] < 1:
        pokemonavv['ps'] = 0
    hpavv = pygame.image.load(".\\schermate lotta\\hp avv.png").convert_alpha()
    schermo.blit(hpavv, (0,70))
    hpmio = pygame.image.load(".\\schermate lotta\\hp mio.png").convert_alpha()
    schermo.blit(hpmio, (500,340))
    hpio = font2.render(str(pokemonmio['ps']), True, bianco)
    schermo.blit(hpio,(625,355))
    hpav = font2.render(str(pokemonavv['ps']), True, bianco)
    schermo.blit(hpav,(95,85))
    pygame.display.update()
    
def attaccoavv():
    schermo.fill(bianco)
    sfondol=pygame.image.load(".\\foto sfondo\\sfondo lotta\\sfondo lotta.png")
    schermo.blit(sfondol,(0,0))
    fotopokeavv = pokemonavv['davanti']
    schermo.blit(fotopokeavv,(500,60))
    fotopokemio = pokemonmio['dietro']
    schermo.blit(fotopokemio,(100,250))
    hpavv = pygame.image.load(".\\schermate lotta\\hp avv.png").convert_alpha()
    schermo.blit(hpavv, (0,70))
    hpmio = pygame.image.load(".\\schermate lotta\\hp mio.png").convert_alpha()
    schermo.blit(hpmio, (500,340))
    hpio = font2.render(str(pokemonmio['ps']), True, bianco)
    schermo.blit(hpio,(625,355))
    hpav = font2.render(str(pokemonavv['ps']), True, bianco)
    schermo.blit(hpav,(95,85))
    pygame.display.update()
    mossaavv = pokemonavv['mosse'][random.randint(0,3)]
    mossa(mossaavv,pokemonmio,pokemonavv)
    
def animazionemossa(mm,poke,pokecontro):
    suono = poke['verso']
    suono.play()
    if pokecontro == pokemonmio:
        azione=pygame.image.load(".\\azione\\az1.png")
        schermo.blit(azione,(125,300))
        pygame.display.update()
        time.sleep(0.40)
        azione=pygame.image.load(".\\azione\\az2.png")
        schermo.blit(azione,(125,300))
        pygame.display.update()
        time.sleep(0.40)
        azione=pygame.image.load(".\\azione\\az3.png")
        schermo.blit(azione,(125,300))
        pygame.display.update()
        time.sleep(0.40)
    elif pokecontro == pokemonavv:
        azione=pygame.image.load(".\\azione\\az1.png")
        schermo.blit(azione,(550,110))
        pygame.display.update()
        time.sleep(0.40)
        azione=pygame.image.load(".\\azione\\az2.png")
        schermo.blit(azione,(550,110))
        pygame.display.update()
        time.sleep(0.40)
        azione=pygame.image.load(".\\azione\\az3.png")
        schermo.blit(azione,(550,110))
        pygame.display.update()
        time.sleep(0.40)
    schermo.fill(bianco)
    sfondol=pygame.image.load(".\\foto sfondo\\sfondo lotta\\sfondo lotta.png")
    schermo.blit(sfondol,(0,0))
    fotopokeavv = pokemonavv['davanti']
    schermo.blit(fotopokeavv,(500,60))
    fotopokemio = pokemonmio['dietro']
    schermo.blit(fotopokemio,(100,250))
    pygame.display.update()
    dialogo=pygame.image.load(".\\foto sfondo\\sfondo lotta\\dialogo.png")
    schermo.blit(dialogo,(0,478))
    testo = font.render(f"{poke['nome']} usa {mm['nome']}!", True, (0,0,0))
    schermo.blit(testo, (30, 500))
    pygame.display.update()
    time.sleep(0.5)
    if eff == 1:
        testo = font.render(f"É poco efficace!", True, (0,0,0))
        schermo.blit(testo, (30, 535))
        pygame.display.update()
    elif eff == 2:
        testo = font.render(f"É superefficace!", True, (0,0,0))
        schermo.blit(testo, (30, 535))
        pygame.display.update()
    elif eff == 3:
        testo = font.render(f"Non ha effetto", True, (0,0,0))
        schermo.blit(testo, (30, 535))
        pygame.display.update()
    time.sleep(1.0)
   
def turni():
    while pokemonmio['ps'] > 1 and pokemonavv['ps'] > 1:
        if pokemonmio['velox'] > pokemonavv['velox']:
            print(pokemonmio['ps'],pokemonavv['ps']) 
            mostramosse()
            attaccomio()
            if pokemonavv['ps'] < 1:
                time.sleep(2.0)
                mostrafine(1)
                break
            attaccoavv()
            if pokemonmio['ps'] < 1:
                time.sleep(2.0)
                mostrafine(0)
                break
        else:
            print(pokemonmio['ps'],pokemonavv['ps']) 
            attaccoavv()
            if pokemonmio['ps'] < 1:
                time.sleep(2.0)
                mostrafine(0)
                break
            mostramosse()
            attaccomio()
            if pokemonavv['ps'] < 1:
                time.sleep(2.0)
                mostrafine(1)
                break
 
def mostrafine(ff):
    if ff == 1:
        schermo.fill(bianco)
        sfondol=pygame.image.load(".\\foto sfondo\\sfondo lotta\\sfondo lotta.png")
        schermo.blit(sfondol,(0,0))
        fotopokemio = pokemonmio['dietro']
        schermo.blit(fotopokemio,(100,250))
        pygame.display.update()
        dialogo=pygame.image.load(".\\foto sfondo\\sfondo lotta\\dialogo.png")
        schermo.blit(dialogo,(0,478))
        suono = pokemonmio['verso']
        suono.play()
        time.sleep(1)
        suono = pygame.mixer.Sound('.\\altri suoni\\vittoria.wav')
        suono.play()
        testo = font.render(f"{pokemonavv['nome']} é esausto!", True, (0,0,0))
        schermo.blit(testo, (30, 500))
        pygame.display.update()
        time.sleep(2.0)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\vinto 25.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
        time.sleep(0.25)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\vinto 50.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
        time.sleep(0.25)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\vinto 75.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
        time.sleep(0.25)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\vinto 100.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
    else:
        schermo.fill(bianco)
        sfondol=pygame.image.load(".\\foto sfondo\\sfondo lotta\\sfondo lotta.png")
        schermo.blit(sfondol,(0,0))
        fotopokeavv = pokemonavv['davanti']
        schermo.blit(fotopokeavv,(500,60))
        pygame.display.update()
        dialogo=pygame.image.load(".\\foto sfondo\\sfondo lotta\\dialogo.png")
        schermo.blit(dialogo,(0,478))
        suono = pokemonavv['verso']
        suono.play()
        time.sleep(1)
        suono = pygame.mixer.Sound('.\\altri suoni\\sconfitta.wav')
        suono.play()
        testo = font.render(f"{pokemonmio['nome']} é esausto!", True, (0,0,0))
        schermo.blit(testo, (30, 500))
        pygame.display.update()
        time.sleep(2.0)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\perso 25.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
        time.sleep(0.25)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\perso 50.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
        time.sleep(0.25)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\perso 75.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
        time.sleep(0.25)
        fine=pygame.image.load(".\\foto sfondo\\sfondo fine\\perso 100.png")
        schermo.blit(fine,(0,0))
        pygame.display.update()
        
pygame.mixer.music.load(".\\altri suoni\\sottofondo.wav")
pygame.mixer.music.play(-1)
max = 0
countscelta = 0
esc_avvenuto = False
sfondoiniziale()
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit() 
            sys.exit()
            
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                while max!=1:    
                    max+=1
                    sfondoscelta()
                    animazionipokemon()
                    schermo.blit(pok1,(295, 45))
                    schermo.blit(pok2,(35, 147))
                    schermo.blit(pok3,(565, 147))  
                    esc_avvenuto = True
                    
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if esc_avvenuto and countscelta==0:
                if event.button == 1:
                    countscelta = 1
                    scelta()
                    vedipoke()
                    sfondolotta()
                    
            elif countscelta == 1:
                if event.button == 1:
                    countscelta = 2
                    pulsantelotta()
                    turni()
                    
                              
    pygame.display.update()
    FPS_CLOCK.tick(30)               
